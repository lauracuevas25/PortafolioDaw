let retoño=0.8;
let aniosPasados=prompt("Cuantos años han pasado?");
let crecimientoAnios=Number(aniosPasados)*0.2;
 alert("El arbol crecerá "+( crecimientoAnios+retoño) +" cm en "+aniosPasados +" años");