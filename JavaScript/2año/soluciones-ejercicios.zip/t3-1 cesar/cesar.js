let clave, intClave, cifra, texto;

// Pide el texto en claro.
do {
    texto = prompt("Escribe el texto que desea cifrar.");
} while(!texto)
document.write(`El texto en claro es: ${texto}.<br>`);

// Pide la clave
do {
    clave = prompt("Escribe la clave (un número entero)");
    intClave = parseInt(clave);
    if(isNaN(clave)) {
        alert("No has introducido un número.");
    }
} while(isNaN(clave))

// Cifra. Este código trabaja con un abecedario sin 'ñ'
document.write('<b>Cifrado básico:</b> ');
for(let letra of texto) {
    if(letra === 'z' && clave > 0) {
        cifra = 'a'.charCodeAt('i') + intClave - 1; // si la letra es z, regresa a la 'a'
    } else {
        cifra = letra.charCodeAt(letra) + intClave;
    }
    document.write(String.fromCharCode(cifra));
}