

function extraerDatos(cadena){
    let campos = ['Nombre', 'Apellido', 'DNI', 'Telefono', 'Email', 'CP'],
        usuario = {};

    // Extraer informacion de la cadena
    let datos = cadena.split(':');

    // Crear objeto usuario asociando los datos extraidos con los nombres de los campos
    for (let i = 0; i < datos.length; ++i) {
        // Assign each element to object
        usuario[campos[i]] = datos[i];
    }

    // Validacion del DNI del usuario y campo dentro del objeto
    usuario.DniValido = validarDni(usuario.DNI);

    // Campo servidor 
    usuario.Servidor = usuario.Email.slice(usuario.Email.indexOf('@') + 1, usuario.Email.length);

    // Username
    usuario.Username = usuario.Nombre.substring(0, 1).toLowerCase() + '_' + usuario.Apellido.slice(-3).toLowerCase();

    // Pais
    usuario.Pais = '\u{1f1e6}\u{1f1fa}'; // bandera representada por 2 caracteres unicode juntos

    return usuario;
}

// Aproximación para validar DNI sin RegExp
function validarDni(dni) {

    let letraCalculada, 
        res = false, 
        letrasDni = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];

    if ((dni.substring(0, dni.length - 1) >= 0) && (dni.substring(0, dni.length - 1) <= 99999999)) {

        letraCalculada = letrasDni[dni.substring(0, dni.length - 1) % 23];

        if (dni.slice(-1).toUpperCase() == letraCalculada) {
            res = true;
        }
    }
    return res;
}

// Mostrar información en el lado cliente
function mostrarInfo(usuario){

    document.write('<h1>Datos de Usuario:</h1>');
    document.write('<ul>');
    for (const campo in usuario) {
        document.write(`<li><strong>${campo}</strong>: ${usuario[campo]}</li>`);
    }
    document.write('</ul>');
    console.log(usuario);
}

let cadenas = ['Rocio:Osorno:01101315Y:612345649:rocio@outlook.com:28001',
        'Sonia:Sastre:15340807Z:765430987:ssastre@gmail.com:43071',
        'Olivia:Soriano:46216401X:654567098:osor01@educa.madrid.org:28660',
        'Elena:Costaguta:70068005T:7123098654:ecostag@madrid.org:45230',
        'Orestes:Sosa:52243028T::sosaorestes2000@yahoo.com:28001'
    ], 
    nOsos = 0;

for (let cadena of cadenas) {
    let usuario = extraerDatos(cadena);
    mostrarInfo(usuario);
    // Alert
    if((usuario.Nombre.slice(0,1).toLowerCase()+usuario.Apellido.slice(0,2).toLowerCase()) == 'oso'){
        nOsos++;
    }
}

if (nOsos>0)
    alert(`Cuidado hay ${nOsos} osos cerca`);
