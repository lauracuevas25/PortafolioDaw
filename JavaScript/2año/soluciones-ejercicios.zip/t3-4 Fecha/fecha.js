let cta = 5,// Variable asociada a los segundos de la cuenta regresiva
    ctaReg = setInterval(actualizaCta, 1000); // se ejecuta la funcion actualizaCta cada segundo

function actualizaCta() {
    console.log(`${cta}`);
    cta--; // Decrementar variable que se muestra por consola

    if (cta <= 0) {
        clearInterval(ctaReg);
        document.write(`<h1>${new Date()}</h1>`)
        //document.write(`<h1>${new Date(.toDateString()}</h1>`)
    }
}