let nevera = new Map(),

    lacteos = new Map([['leche entera', 2], ['yogur natural',5], ['queso feta', 1]]),
    frutas = new Map([['manzanas', 5], ['peras', 1], ['plátanos',1], ['naranjas',2]]),
    vegetales = new Map([['zanahorias', 1], ['pimientos', 4], ['patatas', 3]]),

    reserva = 'Hay reservas de: ',
    compra = 'Hace falta comprar: ';

nevera.set('lacteos', lacteos);
nevera.set('frutas', frutas);
nevera.set('vegetales', vegetales);

// Recorrido de map exterior (Nevera)
for (let balda of nevera) {

    console.log('En ' + balda[0].toUpperCase() + ' hay: ');
    //Recorrido de cada uno de los map dentro del principal
    for (let [prod, cant] of balda[1]) {
        
        console.log(`${prod}`);
        if (cant >= 2) {
            reserva += `\n- ${prod}`;
        } else {
            compra += `\n- ${prod}`;
        }
    }
}
console.log(reserva);
console.log(compra);