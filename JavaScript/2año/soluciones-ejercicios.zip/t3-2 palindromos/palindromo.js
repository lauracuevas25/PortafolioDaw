function esPalindromo(str) {
    
    let reverseStr = str.replaceAll(' ', '').toLowerCase().split('').reverse().join(''); 
    // replaceAll(' ', '')  -> Reemplaza todos los espacios ' ' de la cadena original por cadenas vacias ''
    // toLowerCase()        -> Convierte todos los caracteres a minúsculas
    // split('')            -> Devuelve un array con los caracteres de la cadena
    // reverse())           -> Invierte el orden de los elementos de un array
    // join('')             -> Junta nuevamente los elementos del array 

    return reverseStr === str.replaceAll(' ', '').toLowerCase();
}
