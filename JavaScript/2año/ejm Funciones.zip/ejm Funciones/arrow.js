// Return explícito
// a => { return a }

// Return implícito
// a => a

// Múltiples Parámetros, paréntesis necesarios
// (a, b) => a + b


/* CUÁNDO USAR PARÉNTESIS */

const implicit = () => '(return implícito) Genial!'
console.log(implicit());    // devuelve 'Genial!', 
                            // también funciona en multi-línea

const explicit = () => { return '(return explícito al usar {}) Genial!' }
console.log(explicit());    // devuelve 'Genial!'

const broken = () => { 'Que mal!' }
console.log(broken());      // devuelve undefined

function ternary() {
    return true ? '(ternary) Genial!' : '(ternary) Ni lo sueñes!'
}
console.log(ternary());     // devuelve 'Genial!'

/*
function statement() { 
  return if (true) { 'Genial!' } else { 'Ni lo sueñes!' } 
}
statement();    // salta un SyntaxError
*/

const multiple = () => {
    const flag = Math.random() > 0.5
    return flag ? '(multiple) Genial!' : '(multiple) Espectacular!'
}
console.log(multiple());    // devuelve 'Genial!' o 'Espectacular!'
