alert("¡Bienvenid@ a 2º DAW!");
console.log("IES Arquitecto Ventura Rodriguez");

