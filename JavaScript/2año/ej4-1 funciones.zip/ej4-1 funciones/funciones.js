function saludoParam(mensaje) {
    console.log(mensaje);
}
saludoParam('1. Hola, Mundo');

function saludo() {
    console.log('2. ¡Hola, Mundo!');
}
saludo();
//saludo('Hola'); // funciona

function saludoDefecto(mensaje='3.1 Hola') {
    console.log(mensaje);
}
saludoDefecto(); //'3.1 Hola'
saludoDefecto('3.2 Buenos días'); //'3.2 Buenos días'

function doble(numero) {
    return (numero * 2);
}
console.log('4. ' + doble(3));

function parImpar(numero) {
    if(numero % 2 == 0) { 
        return 'par'; 
        //console.log('par');
    } else { 
        return 'impar'; 
        //console.log('impar');
    }
}
console.log('4. ' + parImpar(3));
//parImpar(3)
console.log('5. ' + parImpar(4));
//parImpar(4)

function mayor(array) {
    let my = 0;
    for(let i of array) {
        if(my < i){
            my = i;
        }
    }
    return my;
}
console.log('6. ' + mayor([4,2,5,3,1]));
console.log('7. ' + mayor([1,5,2,'hola',1]));

/* FUNCIONES ANÓNIMAS */
const triple = function (n) {
    return 3 * n;
}
console.log('8. ' + triple(4));

let x = triple; // referencia a la función
console.log('9. ' + x(5));
let y = triple(4); // valor tras ejecutar la función
console.log('10. ' + y);

/* FUNCIONES FLECHA */
const trip = n => n * 3;
console.log('11. ' + trip(6));
 

