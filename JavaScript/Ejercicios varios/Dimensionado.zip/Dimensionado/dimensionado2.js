var cuerpo = document.getElementById("cuerpo");
var altura = 10;
var ancho = 10;
document.addEventListener("keydown", manejarTecla);
function manejarTecla(event) {
    console.log(event.key);
  ajustarTamano(event.key);
}
