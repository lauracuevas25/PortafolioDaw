function Carta(palo, valor) {
    if (palo >= 1 && palo <= 4 && valor >= 1 && valor <= 10) {
        this.palo = palo;
        this.valor = valor;
    }

    this.darValor = function (nuevoPalo, nuevoValor) {
        if (nuevoPalo >= 1 && nuevoPalo <= 4 && nuevoValor >= 1 && nuevoValor <= 10) {
            this.palo = nuevoPalo;
            this.valor = nuevoValor;
        }
    };

    this.toString = function () {
        const palos = ["Oros", "Espadas", "Bastos", "Copas"];
        const valores = ["As", "2", "3", "4", "5", "6", "7", "8", "Sota", "Caballo", "Rey"];
        return `${valores[this.valor - 1]} de ${palos[this.palo - 1]}`;
    };
}

function Baraja() {
    this.cartas = [];

    for (let palo = 1; palo <= 4; palo++) {
        for (let valor = 1; valor <= 10; valor++) {
            this.cartas.push(new Carta(palo, valor));
        }
    }

    this.barajar = function () {
        for (let i = this.cartas.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this.cartas[i], this.cartas[j]] = [this.cartas[j], this.cartas[i]];
        }
    };

    this.toString = function () {
        return this.cartas.map(carta => carta.toString()).join('\n');
    };
}

// Ejemplo de uso
const miBaraja = new Baraja();
console.log("Baraja inicial:\n" + miBaraja.toString());
miBaraja.barajar();
console.log("\nBaraja barajada:\n" + miBaraja.toString());
