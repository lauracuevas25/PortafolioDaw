document.addEventListener('DOMContentLoaded', function () {
    const capa = document.getElementById('miCapa');

    capa.addEventListener('mouseenter', function () {
        capa.style.backgroundColor = 'green';
    });

    capa.addEventListener('mouseleave', function () {
        capa.style.backgroundColor = 'transparent';
    });

    capa.addEventListener('mousedown', function (event) {
        if (event.button === 0) {
            // Botón principal (izquierdo)
            capa.style.backgroundColor = 'red';
        } else if (event.button === 2) {
            // Botón secundario (derecho)
            event.preventDefault(); // Evitar menú contextual
            capa.style.backgroundColor = 'yellow';
        } else if( event.button === 1){
            capa.style.backgroundColor = 'purple';
        }
    });

    capa.addEventListener('mouseup', function () {
        capa.style.backgroundColor = 'blue';
    });
});
